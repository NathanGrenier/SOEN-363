The `data_backup.sql` file was generated using `pg_dump -U postgres -d db -f data_backup.sql --data-only --column-inserts`.

You can run the file in pgadmin to populate the database. 