There are folder for each part of the assignment. 

When an environment needs to be set up or code needs to be run, a `README.md` can be found in the subfolders explaining what to do.